from django.contrib import admin

# Register your models here.
from .models import Registrations,Blog

admin.site.register(Registrations)
admin.site.register(Blog)
