from django.shortcuts import render
from django.shortcuts import redirect
from blog.models import *
# Create your views here.
def index(request):
    return render(request, 'index.html', {})
def login(request):
   return render(request,'login.html',{})
def welcome(request):
   name = request.session['user']
   print(name)
   datas = Blog.objects.filter(user__name=name).values()
   print(datas)
   return render(request, 'welcome.html', {"name":name,"datas":datas})
def blog(request):
   return render(request, 'blog.html', {})
def Registration(request):
    return render(request,'Registration.html',{})
def RegistrationSave(request):
   name = request.POST.get("name","")
   print(name)
   email = request.POST.get("email", "")
   print(email)
   psw = request.POST.get("psw", "")
   print(psw)

   reg=Registrations()
   reg.name=name
   reg.email=email
   reg.password=psw
   reg.save()

   return redirect('login')
def signin(request):
   name = request.POST.get("name","")
   password = request.POST.get("password", "")
   try:
      x=Registrations.objects.get(name=name, password=password)
      request.session['user'] = x.name

   except:
      x=False
   if x:
      return redirect('welcome')
   else:
      return redirect('login')
def crblog(request):
   user = request.session['user']
   print(user)
   title = request.POST.get("title","")
   body = request.POST.get("body", "")
   user = Registrations.objects.get(name=user)

   pos = Blog()
   pos.user = user
   pos.title=title
   pos.body=body
   pos.save()
   return redirect('index')